<?php
include "dbConnec.php";

?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100 bg-dark">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                 
                    <div class="col mr-2">
                      <div class="text-xl font-weight-bold text-uppercase mb-1 text-light"> Admission Fee </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                     <b class="text-light">5420</b>
                      </div>

                    </div>
                    
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100 bg-dark">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                  
                    <div class="col mr-2">
                      <div class="text-xl font-weight-bold text-uppercase mb-1 text-light"> Registration Fee </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      <b class="text-light">5400</b>
                      </div>

                    </div>
                    
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100 bg-dark">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                  
                    <div class="col mr-2">
                      <div class="text-xl font-weight-bold text-uppercase mb-1 text-light"> Monthly Fee </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      <b class="text-light">5400</b>
                      </div>

                    </div>
                   
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4 ">
              <div class="card h-100 bg-dark">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                  
                    <div class="col mr-2">
                      <div class="text-xl font-weight-bold text-uppercase mb-1 text-light"> Books Fee</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      <b class="text-light">5400</b>
                      </div>

                    </div>
                   
                    
                  </div>
                </div>
              </div>
            </div>