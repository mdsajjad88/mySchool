<?php


echo "EKHONO SALRAY DETAILS DEKHAONOR KAJ KORA HOYNI..........................."

?>